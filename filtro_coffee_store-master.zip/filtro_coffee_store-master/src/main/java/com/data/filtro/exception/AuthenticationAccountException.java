package com.data.filtro.exception;

public class AuthenticationAccountException extends RuntimeException {
    public AuthenticationAccountException(String message) {
        super(message);
    }
}
